# M5 — XGBoost (Aadrikaa)

## What was done
- Trained an XGBoost classifier on the same data, features, split (80/20, `random_state=42`, stratified) and preprocessing as the Logistic Regression notebook (M3).
- Handled class imbalance with `scale_pos_weight` (equivalent of M3's `class_weight="balanced"`).
- Tuned 4 parameters (max_depth, learning_rate, n_estimators, min_child_weight) with 5-fold CV on the training set only.
- Evaluated once on the test set; saved the full pipeline as `xgboost.pkl`.

## Results (test set, 1,409 customers, threshold 0.5)
| Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|
| 0.7424 | 0.5094 | 0.7995 | 0.6223 | 0.8443 |

Confusion matrix: TN 747, FP 288, FN 75, TP 299.
Best params: max_depth=2, learning_rate=0.03, n_estimators=300, min_child_weight=5.

## How to run
1. `pip install xgboost scikit-learn pandas numpy matplotlib seaborn joblib`
2. Keep `telco_with_ids.csv` (M2 output) next to the notebook.
3. Open `05_xgboost.ipynb` and Restart & Run All (about 1 minute, no GPU).

## Files
- `05_xgboost.ipynb` — executed notebook
- `xgboost.pkl` — pipeline (preprocessing + XGBoost); takes raw customer columns
- `xgboost_metrics.csv / .json` — metrics for M6
- `xgboost_test_predictions.csv` — customerID, actual, predicted, probability on the shared test rows
- `xgboost_feature_importance.csv` — for M7 / Power BI
- `figures/` — confusion matrix, ROC curve (with Logistic Regression), feature importance

## What the next members need
- M6: use the same split to compare all three models; XGBoost is only +0.003 ROC-AUC over Logistic Regression, so justify the recommendation on recall/F1/interpretability, not accuracy alone.
- M7: load `xgboost.pkl` with joblib (scikit-learn >= 1.9 was used; keep versions consistent across the team).
